<template>
    <div>This is Employers</div>
</template>

<script>
    export default {
        name: "employers-component"
    }
</script>

<style scoped>

</style>