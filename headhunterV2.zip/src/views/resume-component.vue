<template>
    <div>This is Resume</div>
</template>

<script>
    export default {
        name: "resume-component"
    }
</script>

<style scoped>

</style>