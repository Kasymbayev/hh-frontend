<template>
    <div>
        2
    </div>
</template>

<script>
    export default {
        name: "footer-component"
    }
</script>

<style scoped>

</style>