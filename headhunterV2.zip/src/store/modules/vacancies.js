import Vue from "vue";
import Vuex from "vuex";
import vacancies from "../../api/vacancy";

Vue.use(Vuex);

const state = () => ({
    list: [],
    select: {},
});

const getters = {

    vacancy: state => {
        return state.list;
    },

    detail: state => {
        return state.select;
    }
};

const actions = {
    async getVacancies ({commit}, params = {}) {
        let {
            data
        } = await vacancies.getVacancies(params);

        // Изменение формата даты
        for(let key in data.items) {
            let published_date = new Date(data.items[key].published_at).toLocaleString('ru', {
                month: 'long',
                day: 'numeric'
            });
            data.items[key].published_at = published_date;
        }
        commit("setVacancies", data);
    },

    async getDetailVacancy({commit}, id) {
        let {
            data
        } = await vacancies.getDetailVacancies(id);
        data.description.replace(/\"/g, "");
        commit("setDetailVacancies", data);
    },
};

const mutations = {

    setVacancies (state, vacancy) {
        state.list = vacancy
    },

    setVacanciesSearch(state, data) {
        state.list = [...data.results]
    },

    setDetailVacancies (state, detail) {
        state.select = detail
    }
};

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
};
